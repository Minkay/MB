/*
Author: Pradeep Khodke
URL: http://www.codingcage.com/
*/

		


$('document').ready(function()
{ 

		
	// MENSAJES PERSONALIZADOS


				var com ;	
				$('#at1').click(function(e) {
                	mi = $("#ser").val();               	
                	
                	switch(mi) {						    
								case '4':
								 com ="El servicio de limpieza";
								break;
								case '5':
								 com="Anexos telefónicos";
								break;    
								case '6':
								 com="Dispensador de agua";
								  break; 
								case '7':
								 com="Proyector multimedia";
								  break; 

								case '8':
								 com="Lactario";
								  break; 
								case '9':
								 com="Frio bar de lactario ";
								  break; 
								case '10':
								 com="Kitchen";
								  break; 

								case '11':
								 com="Frio bar";
								  break; 
								case '12':
								 com="Horno microondas";
								  break;
								case '13':
								 com="Dispensador de agua";
								  break;

								case '14':
								 com="Repostero/ Alacena";
								  break; 

								case '15':
								 com="Mesa- Comedor";
								  break; 

								case '16':
								 com="Sumidero de Rack";
								  break;
								case '17':
								 com="SSHH Discapacitados";
								  break;
								case '18':
								 com="Sumidero de SSHH Discapacitados";
								  break; 
								case '19':
								 com="SSHH MIXTO";
								  break; 
								case '20':
								 com="Sumidero de SSHH mixto";
								  break;

							}
					
					 $("textarea").text(com);

                });




				$('#ct1').click(function(e) {
                	mi = $("#ser").val();                	
                	
                	switch(mi) {							    
							    case '4':
								 com ="El servicio de limpieza";
								break;
								case '5':
								 com="Anexos telefónicos";
								break;    
								case '6':
								 com="Dispensador de agua";
								  break; 
								case '7':
								 com="Proyector multimedia";
								  break; 

								case '8':
								 com="Lactario";
								  break; 
								case '9':
								 com="Frio bar de lactario ";
								  break; 
								case '10':
								 com="Kitchen";
								  break; 

								case '11':
								 com="Frio bar";
								  break; 
								case '12':
								 com="Horno microondas";
								  break;
								case '13':
								 com="Dispensador de agua";
								  break;

								case '14':
								 com="Repostero/ Alacena";
								  break; 

								case '15':
								 com="Mesa- Comedor";
								  break; 

								case '16':
								 com="Sumidero de Rack";
								  break;
								case '17':
								 com="SSHH Discapacitados";
								  break;
								case '18':
								 com="Sumidero de SSHH Discapacitados";
								  break; 
								case '19':
								 com="SSHH MIXTO";
								  break; 
								case '20':
								 com="Sumidero de SSHH mixto";
								  break;

							}
					
					 $("textarea").text(com);

                });





				$('#st1').click(function(e) {
                	mi = $("#ser").val();                	
                	
                	switch(mi) {							    
							  case '4':
								 com ="El servicio de limpieza";
								break;
								case '5':
								 com="Anexos telefónicos";
								break;    
								case '6':
								 com="Dispensador de agua";
								  break; 
								case '7':
								 com="Proyector multimedia";
								  break; 

								case '8':
								 com="Lactario";
								  break; 
								case '9':
								 com="Frio bar de lactario ";
								  break; 
								case '10':
								 com="Kitchen";
								  break; 

								case '11':
								 com="Frio bar";
								  break; 
								case '12':
								 com="Horno microondas";
								  break;
								case '13':
								 com="Dispensador de agua";
								  break;

								case '14':
								 com="Repostero/ Alacena";
								  break; 

								case '15':
								 com="Mesa- Comedor";
								  break; 

								case '16':
								 com="Sumidero de Rack";
								  break;
								case '17':
								 com="SSHH Discapacitados";
								  break;
								case '18':
								 com="Sumidero de SSHH Discapacitados";
								  break; 
								case '19':
								 com="SSHH MIXTO";
								  break; 
								case '20':
								 com="Sumidero de SSHH mixto";
								  break;
								  
							}
					
					 $("textarea").text(com);

                });


				$('#bt1').click(function(e) {
                	mi = $("#ser").val();                	
                	
                	switch(mi) {							    
							   case '4':
								 com ="El servicio de limpieza";
								break;
								case '5':
								 com="Anexos telefónicos";
								break;    
								case '6':
								 com="Dispensador de agua";
								  break; 
								case '7':
								 com="Proyector multimedia";
								  break; 

								case '8':
								 com="Lactario";
								  break; 
								case '9':
								 com="Frio bar de lactario ";
								  break; 
								case '10':
								 com="Kitchen";
								  break; 

								case '11':
								 com="Frio bar";
								  break; 
								case '12':
								 com="Horno microondas";
								  break;
								case '13':
								 com="Dispensador de agua";
								  break;

								case '14':
								 com="Repostero/ Alacena";
								  break; 

								case '15':
								 com="Mesa- Comedor";
								  break; 

								case '16':
								 com="Sumidero de Rack";
								  break;
								case '17':
								 com="SSHH Discapacitados";
								  break;
								case '18':
								 com="Sumidero de SSHH Discapacitados";
								  break; 
								case '19':
								 com="SSHH MIXTO";
								  break; 
								case '20':
								 com="Sumidero de SSHH mixto";
								  break;

							}
					
					 $("textarea").text(com);

                });


			// FIN DE MENSAJES	
	
});