/*
Author: Pradeep Khodke
URL: http://www.codingcage.com/
*/

		


$('document').ready(function()
{ 

		
	// MENSAJES PERSONALIZADOS


				var com ;	
				$('#at1').click(function(e) {
                	mi = $("#mo").val();               	
                	
                	switch(mi) {
                				case '1':
							         com ="Bnaquetas de espera";
							        break;
							    case '2':
							         com="Sillas fijas";
							        break; 
                				case '3':
							         com ="Sillas giratorias";
							        break;
							    case '4':
							         com="Tachos.";
							        break; 
                				case '5':
							         com ="Ordenadores de cola";
							        break;
							    case '6':
							         com="Modulos de atencion";
							        break;
							    case '7':
							         com ="Estantes";
							        break;
							    case '8':
							         com="Credenzas";
							        break;  							    
							    case '9':
							         com ="Los anaqueles del área de archivo";
							        break;
							    case '10':
							         com="Los anaqueles del área de economato.";
							        break; 
							}
					
					 $("textarea").text(com);

                });




				$('#ct1').click(function(e) {
                	mi = $("#mo").val();                	
                	
                	switch(mi) {							    
							   case '1':
							         com ="Bnaquetas de espera";
							        break;
							    case '2':
							         com="Sillas fijas";
							        break; 
                				case '3':
							         com ="Sillas giratorias";
							        break;
							    case '4':
							         com="Tachos.";
							        break; 
                				case '5':
							         com ="Ordenadores de cola";
							        break;
							    case '6':
							         com="Modulos de atencion";
							        break;
							    case '7':
							         com ="Estantes";
							        break;
							    case '8':
							         com="Credenzas";
							        break;  							    
							    case '9':
							         com ="Los anaqueles del área de archivo";
							        break;
							    case '10':
							         com="Los anaqueles del área de economato.";
							        break; 
							   
							}
					
					 $("textarea").text(com);

                });





				$('#st1').click(function(e) {
                	mi = $("#mo").val();                	
                	
                	switch(mi) {							    
							    case '1':
							         com ="Bnaquetas de espera";
							        break;
							    case '2':
							         com="Sillas fijas";
							        break; 
                				case '3':
							         com ="Sillas giratorias";
							        break;
							    case '4':
							         com="Tachos.";
							        break; 
                				case '5':
							         com ="Ordenadores de cola";
							        break;
							    case '6':
							         com="Modulos de atencion";
							        break;
							    case '7':
							         com ="Estantes";
							        break;
							    case '8':
							         com="Credenzas";
							        break;  							    
							    case '9':
							         com ="Los anaqueles del área de archivo";
							        break;
							    case '10':
							         com="Los anaqueles del área de economato.";
							        break; 
							}
					
					 $("textarea").text(com);

                });


				$('#bt1').click(function(e) {
                	mi = $("#mo").val();                	
                	
                	switch(mi) {							    
							   case '1':
							         com ="Bnaquetas de espera";
							        break;
							    case '2':
							         com="Sillas fijas";
							        break; 
                				case '3':
							         com ="Sillas giratorias";
							        break;
							    case '4':
							         com="Tachos.";
							        break; 
                				case '5':
							         com ="Ordenadores de cola";
							        break;
							    case '6':
							         com="Modulos de atencion";
							        break;
							    case '7':
							         com ="Estantes";
							        break;
							    case '8':
							         com="Credenzas";
							        break;  							    
							    case '9':
							         com ="Los anaqueles del área de archivo";
							        break;
							    case '10':
							         com="Los anaqueles del área de economato.";
							        break; 
							}
					
					 $("textarea").text(com);

                });


			// FIN DE MENSAJES	
	
});