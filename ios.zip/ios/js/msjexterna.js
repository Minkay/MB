/*
Author: Pradeep Khodke
URL: http://www.codingcage.com/
*/

		


$('document').ready(function()
{ 

		
	// MENSAJES PERSONALIZADOS


				var com ;	
				$('#at1').click(function(e) {
                	mi = $("#ext").val();               	
                	
                	switch(mi) {							    
							    case '1':
							         com ="Friso luminoso o letrero C. Histórico";
							        break;
							    case '2':
							         com="Puerta principal";
							        break;    
							    case '3':
							         com="Paredes de fachada";
							          break; 
							    case '4':
							         com="Vidrios de fachada";
							          break; 
							    case '5':
							         com="Retiro municipal";
							          break; 
							    case '6':
							         com="Vereda";
							          break; 
							   

							}
					
					 $("textarea").text(com);

                });




				$('#ct1').click(function(e) {
                	mi = $("#ext").val();                	
                	
                	switch(mi) {							    
							    case '1':
							         com ="Friso luminoso o letrero C. Histórico";
							        break;
							    case '2':
							         com="Puerta principal";
							        break;    
							    case '3':
							         com="Paredes de fachada";
							          break; 
							    case '4':
							         com="Vidrios de fachada";
							          break; 
							    case '5':
							         com="Retiro municipal";
							          break; 
							    case '6':
							         com="Vereda";
							          break; 
							   
							}
					
					 $("textarea").text(com);

                });





				$('#st1').click(function(e) {
                	mi = $("#ext").val();                	
                	
                	switch(mi) {							    
							    case '1':
							         com ="Friso luminoso o letrero C. Histórico";
							        break;
							    case '2':
							         com="Puerta principal";
							        break;    
							    case '3':
							         com="Paredes de fachada";
							          break; 
							    case '4':
							         com="Vidrios de fachada";
							          break; 
							    case '5':
							         com="Retiro municipal";
							          break; 
							    case '6':
							         com="Vereda";
							          break; 
							   
							}
					
					 $("textarea").text(com);

                });


				$('#bt1').click(function(e) {
                	mi = $("#ext").val();                	
                	
                	switch(mi) {							    
							     case '1':
							         com ="Friso luminoso o letrero C. Histórico";
							        break;
							    case '2':
							         com="Puerta principal";
							        break;    
							    case '3':
							         com="Paredes de fachada";
							          break; 
							    case '4':
							         com="Vidrios de fachada";
							          break; 
							    case '5':
							         com="Retiro municipal";
							          break; 
							    case '6':
							         com="Vereda";
							          break; 
							   
							}
					
					 $("textarea").text(com);

                });


			// FIN DE MENSAJES	
	
});