/*
Author: Pradeep Khodke
URL: http://www.codingcage.com/
*/

		


$('document').ready(function()
{ 

		
	// MENSAJES PERSONALIZADOS


				var com ;	
				$('#at1').click(function(e) {
                	mi = $("#eq").val();               	
                	
                	switch(mi) {
                				case '1':
							         com ="Instalaciones eléctricas y de red";
							        break;
							    case '2':
							         com="Iluminación";
							        break; 							    
							    case '3':
							         com ="UPS";
							        break;
							    case '4':
							         com="Grupo electrógeno";
							        break;    
							    case '5':
							         com="Aire acondicionado";
							          break; 
							    case '6':
							         com="Rack Servidor";
							          break; 
							    case '7':
							         com="Cisterna y Bombas";
							          break; 
							    case '8':
							         com="Tanque elevado";
							          break;
							    case '9':
							         com ="TV o DVD";
							        break;
							    case '10':
							         com="Luces de emergencia";
							        break;    
							    case '11':
							         com="Extintores";
							          break; 
							    case '12':
							         com="Persianas";
							          break; 
							    case '13':
							         com="Pozo a tierra";
							          break; 
							   

							}
					
					 $("textarea").text(com);

                });




				$('#ct1').click(function(e) {
                	mi = $("#eq").val();                	
                	
                	switch(mi) {
                				case '1':
							         com ="Instalaciones eléctricas y de red";
							        break;
							    case '2':
							         com="Iluminación";
							        break; 						    
							       case '3':
							         com ="UPS";
							        break;
							    case '4':
							         com="Grupo electrógeno";
							        break;    
							    case '5':
							         com="Aire acondicionado";
							          break; 
							    case '6':
							         com="Rack Servidor";
							          break; 
							    case '7':
							         com="Cisterna y Bombas";
							          break; 
							    case '8':
							         com="Tanque elevado";
							          break;
							    case '9':
							         com ="TV o DVD";
							        break;
							    case '10':
							         com="Luces de emergencia";
							        break;    
							    case '11':
							         com="Extintores";
							          break; 
							    case '12':
							         com="Persianas";
							          break; 
							    case '13':
							         com="Pozo a tierra";
							          break; 
							}
					
					 $("textarea").text(com);

                });





				$('#st1').click(function(e) {
                	mi = $("#eq").val();                	
                	
                	switch(mi) {

                				case '1':
							         com ="Instalaciones eléctricas y de red";
							        break;
							    case '2':
							         com="Iluminación";
							        break; 

							     case '3':
							         com ="UPS";
							        break;
							    case '4':
							         com="Grupo electrógeno";
							        break;    
							    case '5':
							         com="Aire acondicionado";
							          break; 
							    case '6':
							         com="Rack Servidor";
							          break; 
							    case '7':
							         com="Cisterna y Bombas";
							          break; 
							    case '8':
							         com="Tanque elevado";
							          break;
							    case '9':
							         com ="TV o DVD";
							        break;
							    case '10':
							         com="Luces de emergencia";
							        break;    
							    case '11':
							         com="Extintores";
							          break; 
							    case '12':
							         com="Persianas";
							          break; 
							    case '13':
							         com="Pozo a tierra";
							          break; 
							   
							}
					
					 $("textarea").text(com);

                });


				$('#bt1').click(function(e) {
                	mi = $("#eq").val();                	
                	
                	switch(mi) {  
                				case '1':
							         com ="Instalaciones eléctricas y de red";
							        break;
							    case '2':
							         com="Iluminación";
							        break; 
							        
							      case '3':
							         com ="UPS";
							        break;
							    case '4':
							         com="Grupo electrógeno";
							        break;    
							    case '5':
							         com="Aire acondicionado";
							          break; 
							    case '6':
							         com="Rack Servidor";
							          break; 
							    case '7':
							         com="Cisterna y Bombas";
							          break; 
							    case '8':
							         com="Tanque elevado";
							          break;
							    case '9':
							         com ="TV o DVD";
							        break;
							    case '10':
							         com="Luces de emergencia";
							        break;    
							    case '11':
							         com="Extintores";
							          break; 
							    case '12':
							         com="Persianas";
							          break; 
							    case '13':
							         com="Pozo a tierra";
							          break; 
							}
					
					 $("textarea").text(com);

                });


			// FIN DE MENSAJES	
	
});